import { Header } from "./components/Header";
import { AddTodo } from "./components/AddTodo";
import { TodosList } from "./components/TodosList";

function App() {
  return (
    <div className="main-container">
      <Header />
      <AddTodo />
      <TodosList />
    </div>
  );
}

export default App;
