import React from "react";

export const Header = () => {
  return <h1>Todo Application</h1>;
};
