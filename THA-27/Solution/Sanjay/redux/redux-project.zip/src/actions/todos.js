const addTodo = todo => {
  return {
    type: "ADD_TODO",
    payload: todo
  };
};

const removeTodo = id => {
  return {
    type: "REMOVE_TODO",
    payload: id
  };
};

const loadFakeTodos = () => {
  return dispatch => {
    fetch("https://jsonplaceholder.typicode.com/todos")
      .then(res => res.json())
      .then(todos => {
        return dispatch({
          type: "LOAD_FAKE_TODOS",
          payload: todos.slice(0, 10).map(todo => todo.title)
        });
      })
      .catch(err => {
        console.log(err);
        return dispatch({
          type: "LOAD_FAKE_TODOS",
          payload: []
        });
      });
  };
};

const removeAllTodos = () => {
  return {
    type: "REMOVE_ALL_TODOS",
    payload: []
  };
};

export { addTodo, removeTodo, loadFakeTodos, removeAllTodos };
