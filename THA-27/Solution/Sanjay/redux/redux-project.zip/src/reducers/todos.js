const todoReducer = (state = [], action) => {
  switch (action.type) {
    case "ADD_TODO":
      return [...state, action.payload];
    case "REMOVE_TODO":
      return state.filter((todo, index) => index !== action.payload);
    case "LOAD_FAKE_TODOS":
      return [...state, ...action.payload];
    case "REMOVE_ALL_TODOS":
      return [];
    default:
      return state;
  }
};

export default todoReducer;
